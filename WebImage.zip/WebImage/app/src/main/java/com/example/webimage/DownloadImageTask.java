package com.example.webimage;

import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.os.AsyncTask;
import android.provider.SyncStateContract;
import android.widget.ImageView;
import android.widget.Toast;
import android.app.IntentService;


public class DownloadImageTask extends AsyncTask<String, Void, Bitmap> {
    private static final String EXTRA_URL = ;
    private Context context;
    private Bitmap result;


    public DownloadImageTask(Context context) {
        this.context = context;
        Toast.makeText(context, "Please wait, it may take a few seconds.", Toast.LENGTH_SHORT).show();
    }

    protected Bitmap doInBackground(String... urls) {

        Bitmap bmp = null;

        return bmp;


    }

    protected void onPostExecute(Bitmap result) {
        // save bitmap result in application class
        this.result =  result;

        // send intent to stop foreground service

        Intent stopIntent = new Intent(DownloadImageTask.this, ForegroundImageService.class);
        stopIntent.setAction(ForegroundImageService.STARTFOREGROUND_ACTION);
        startService(stopIntent);

    }
}
