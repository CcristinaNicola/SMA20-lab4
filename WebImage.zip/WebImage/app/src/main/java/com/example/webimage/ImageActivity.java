package com.example.webimage;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Bitmap;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.Toast;

public class ImageActivity extends AppCompatActivity {

    private static ImageActivity singleton;
    private Bitmap bitmap;

    public ImageActivity getSingleton() {
        return singleton;
    }

    public Bitmap getBitmap() {
        return bitmap;
    }

    public void setBitmap(Bitmap bitmap) {
        this.bitmap = bitmap;
    }


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        singleton = this;
        setContentView(R.layout.activity_image_layout);

        ImageActivity imageActivity = (ImageActivity) getApplicationContext();
        if (imageActivity.getBitmap() == null) {
            Toast.makeText(this, "Error trasnimtting UR:.", Toast.LENGTH_SHORT).show();
            finish();
        }else{
                ImageView imageView = (ImageView) findViewById(R.id.imageView);
                imageView.setImageBitmap(imageActivity.getBitmap());
            }
        }
    }
