package com.example.webimage;

import androidx.appcompat.app.AppCompatActivity;

import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import java.time.Instant;


public class WebsearchActivity extends AppCompatActivity {


    public static final String EXTRA_URL =" ";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_websearch_layout);
    }

    public void loadImage(View view) {

        ClipboardManager clipboardManager = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
        ClipData abc = clipboardManager.getPrimaryClip();
        ClipData.Item item = abc.getItemAt(0);
        String url = item.getText().toString();

        if(!url.contains("http://goo.gl/images/"))
            Toast.makeText(this, "URL not valid!!! Try another", Toast.LENGTH_SHORT).show();
        else{
            if(view.getId() == R.id.bLoadBackground) {
                Intent intent = new Intent(this, ImageIntentService.class);
                intent.putExtra(EXTRA_URL,url);
                startService(intent);
            }

            else if(view.getId() == R.id.bLoadForeground) {
                Intent startIntents = new Intent(this, ForegroundImageService.class);
                startIntents.setAction(ForegroundImageService.STARTFOREGROUND_ACTION);
                startIntents.putExtra(EXTRA_URL,url);
                startService(startIntents);
            }
    }


    }
}